
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");
  btnText.style.borderWidth = '0px';

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "نمایش بیشتر"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "نمایش کمتر"; 
    // btnText.style.border = "none";
    moreText.style.display = "inline";
  }
}

function openNav() {
  document.getElementById("mySidebar").style.width = "500px";
  document.getElementById("main").style.marginLeft = "500px";
  // document.getElementById("fullcart").style.display="block";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}

function functionomit(){
  document.getElementById("emptycart").style.visibility="visible";
  document.getElementById("fullcart").style.visibility="hidden";
}









          